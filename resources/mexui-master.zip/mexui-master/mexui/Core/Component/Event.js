mexui.Component.Event = function()
{
	this.used				= false;
	this.clickedAControl	= false;
};

